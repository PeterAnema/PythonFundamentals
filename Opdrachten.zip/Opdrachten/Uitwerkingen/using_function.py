from password_generator_function import generate_password

print(generate_password())

