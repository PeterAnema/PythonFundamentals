# Exercise 5.6 from Crash Course for Python

age = int(input('What age? : '))

if age < 2:
    print('A baby')

elif age < 4:
    print('A toddler')

elif 4 <= age < 13:
    print('A kid')

elif age >= 13 and age < 20:
    print('A teenager')

elif 20 <= age < 65:
    print('An adult')

elif age >= 65:
    print('An elder')
