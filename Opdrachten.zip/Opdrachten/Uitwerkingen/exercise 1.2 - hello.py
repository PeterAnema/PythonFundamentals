# This is comment. It will not be executed.

name = input('What is your name? ')     # in 2.7 use raw_input(...)

print('Hello ' + name)

tekst = """regel1
regel2
regel3
"""






